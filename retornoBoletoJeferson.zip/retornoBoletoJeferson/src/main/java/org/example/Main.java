package org.example;

import org.example.LeituraRetornoBancoBrasil;

public class Main {
    public static void main(String[] args) {
        var leituraRetorno = new LeituraRetornoBancoBrasil();
        var processador = new ProcessarBoletos(leituraRetorno);

        processador.setLeituraRetorno(leituraRetorno);
        processador.processar("banco-brasil-1.csv");

        //Leitura Bradesco
        var leituraBradesco = new LeituraRetornoBradesco();
        processador.setLeituraRetorno(leituraBradesco);
        processador.processar("bradesco-1.csv");
    }
}