package org.example;

import lombok.Setter;

@Setter //incluir getters e setters
public class ProcessarBoletos {
    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno){
        this.leituraRetorno = leituraRetorno;
    }

    public void processar(String nomeArquivo){
        var listaBoletos = leituraRetorno.lerArquivo(nomeArquivo);
        System.out.println(listaBoletos);
    }
}
