package org.example;

import org.example.LeituraRetornoBancoBrasil;

public class Main {
    public static void main(String[] args) {

        var processador = new ProcessarBoletos(LeituraRetornoBancoBrasil::lerArquivo);
        processador.processar("banco-brasil-1.csv");

        //Leitura Bradesco
        var leituraBradesco = new ProcessarBoletos(LeituraRetornoBradesco::lerArquivo);
        leituraBradesco.processar("bradesco-1.csv");
    }
}